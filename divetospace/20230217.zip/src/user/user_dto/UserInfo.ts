export interface UserInfo{
    user_nickname: string;
}